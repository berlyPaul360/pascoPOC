package com.pasco.proof_of_concept;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProofOfConceptApplicationTests {

	@Test
	void contextLoads() {
	}

}
