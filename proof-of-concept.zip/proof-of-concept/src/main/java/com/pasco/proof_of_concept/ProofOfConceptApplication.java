package com.pasco.proof_of_concept;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProofOfConceptApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProofOfConceptApplication.class, args);
	}

}
